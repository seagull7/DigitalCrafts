

var box = document.getElementById('contain');
var boxinbox = document.getElementById('center');
var pop = document.createElement("img");

document.getElementById('amumu').onclick = function(e){
    console.log('I am still working')
    if(boxinbox.firstChild){
        center.appendChild(pop);
    }
        pop.setAttribute("class", "centerfold");
        pop.setAttribute("src", "https://ddragon.leagueoflegends.com/cdn/img/champion/splash/Amumu_0.jpg");
};
document.getElementById('ashe').onclick = function(e){
    console.log('I am still working')
    if(boxinbox.firstChild){
        center.appendChild(pop);
    }
        pop.setAttribute("class", "centerfold");
        pop.setAttribute("src", "https://ddragon.leagueoflegends.com/cdn/img/champion/splash/Ashe_0.jpg");
};
document.getElementById('corki').onclick = function(e){
    console.log('I am still working')
    if(boxinbox.firstChild){
        center.appendChild(pop);
    }
        pop.setAttribute("class", "centerfold");
        pop.setAttribute("src", "https://ddragon.leagueoflegends.com/cdn/img/champion/splash/Corki_0.jpg");
};
document.getElementById('fiddle').onclick = function(e){
    console.log('I am still working')
    if(boxinbox.firstChild){
        center.appendChild(pop);
    }
        pop.setAttribute("class", "centerfold");
        pop.setAttribute("src", "https://ddragon.leagueoflegends.com/cdn/img/champion/splash/Fiddlesticks_0.jpg");
};
document.getElementById('garen').onclick = function(e){
    console.log('I am still working')
    if(boxinbox.firstChild){
        center.appendChild(pop);
    }
        pop.setAttribute("class", "centerfold");
        pop.setAttribute("src", "https://ddragon.leagueoflegends.com/cdn/img/champion/splash/Garen_0.jpg");
};
document.getElementById('rammus').onclick = function(e){
    console.log('I am still working')
    if(boxinbox.firstChild){
        center.appendChild(pop);
    }
        pop.setAttribute("class", "centerfold");
        pop.setAttribute("src", "https://ddragon.leagueoflegends.com/cdn/img/champion/splash/Rammus_0.jpg");
};
document.getElementById('xerath').onclick = function(e){
    console.log('I am still working')
    if(boxinbox.firstChild){
        center.appendChild(pop);
    }
        pop.setAttribute("class", "centerfold");
        pop.setAttribute("src", "https://ddragon.leagueoflegends.com/cdn/img/champion/splash/Xerath_0.jpg");
};
document.getElementById('heimer').onclick = function(e){
    console.log('I am still working')
    if(boxinbox.firstChild){
        center.appendChild(pop);
    }
        pop.setAttribute("class", "centerfold");
        pop.setAttribute("src", "https://ddragon.leagueoflegends.com/cdn/img/champion/splash/Heimerdinger_0.jpg");
};
document.getElementById('jax').onclick = function(e){
    console.log('I am still working')
    if(boxinbox.firstChild){
        center.appendChild(pop);
    }
        pop.setAttribute("class", "centerfold");
        pop.setAttribute("src", "https://ddragon.leagueoflegends.com/cdn/img/champion/splash/Jax_0.jpg");
};
document.getElementById('morgana').onclick = function(e){
    console.log('I am still working')
    if(boxinbox.firstChild){
        center.appendChild(pop);
    }
        pop.setAttribute("class", "centerfold");
        pop.setAttribute("src", "https://ddragon.leagueoflegends.com/cdn/img/champion/splash/Morgana_0.jpg");
};
document.getElementById('nasus').onclick = function(e){
    console.log('I am still working')
    if(boxinbox.firstChild){
        center.appendChild(pop);
    }
        pop.setAttribute("class", "centerfold");
        pop.setAttribute("src", "https://ddragon.leagueoflegends.com/cdn/img/champion/splash/Nasus_0.jpg");
};
document.getElementById('taric').onclick = function(e){
    console.log('I am still working')
    if(boxinbox.firstChild){
        center.appendChild(pop);
    }
        pop.setAttribute("class", "centerfold");
        pop.setAttribute("src", "https://ddragon.leagueoflegends.com/cdn/img/champion/splash/Taric_0.jpg");
};
document.getElementById('pantheon').onclick = function(e){
    console.log('I am still working')
    if(boxinbox.firstChild){
        center.appendChild(pop);
    }
        pop.setAttribute("class", "centerfold");
        pop.setAttribute("src", "https://ddragon.leagueoflegends.com/cdn/img/champion/splash/Pantheon_0.jpg");
};
document.getElementById('fortune').onclick = function(e){
    console.log('I am still working')
    if(boxinbox.firstChild){
        center.appendChild(pop);
    }
        pop.setAttribute("class", "centerfold");
        pop.setAttribute("src", "https://ddragon.leagueoflegends.com/cdn/img/champion/splash/MissFortune_0.jpg");
};

